SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Newsletter_IssueContactGroup](
	[IssueContactGroupID] [int] IDENTITY(1,1) NOT NULL,
	[IssueID] [int] NOT NULL,
	[ContactGroupID] [int] NOT NULL,
 CONSTRAINT [PK_Newsletter_IssueContactGroup] PRIMARY KEY CLUSTERED 
(
	[IssueContactGroupID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_Newsletter_IssueContactGroup_ContactGroupID] ON [dbo].[Newsletter_IssueContactGroup]
(
	[ContactGroupID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[Newsletter_IssueContactGroup] ADD  CONSTRAINT [DEFAULT_Newsletter_IssueContactGroup_IssueID]  DEFAULT ((0)) FOR [IssueID]
GO
ALTER TABLE [dbo].[Newsletter_IssueContactGroup] ADD  CONSTRAINT [DEFAULT_Newsletter_IssueContactGroup_ContactGroupID]  DEFAULT ((0)) FOR [ContactGroupID]
GO
ALTER TABLE [dbo].[Newsletter_IssueContactGroup]  WITH CHECK ADD  CONSTRAINT [FK_Newsletter_IssueContactGroup_ContactGroupID] FOREIGN KEY([ContactGroupID])
REFERENCES [dbo].[OM_ContactGroup] ([ContactGroupID])
GO
ALTER TABLE [dbo].[Newsletter_IssueContactGroup] CHECK CONSTRAINT [FK_Newsletter_IssueContactGroup_ContactGroupID]
GO
