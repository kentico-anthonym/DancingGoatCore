SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Analytics_Statistics](
	[StatisticsID] [int] IDENTITY(1,1) NOT NULL,
	[StatisticsSiteID] [int] NULL,
	[StatisticsCode] [nvarchar](400) NOT NULL,
	[StatisticsObjectName] [nvarchar](1000) NULL,
	[StatisticsObjectID] [int] NULL,
	[StatisticsObjectCulture] [nvarchar](50) NULL,
 CONSTRAINT [PK_Analytics_Statistics] PRIMARY KEY NONCLUSTERED 
(
	[StatisticsID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE CLUSTERED INDEX [IX_Analytics_Statistics_StatisticsCode_StatisticsSiteID_StatisticsObjectID_StatisticsObjectCulture] ON [dbo].[Analytics_Statistics]
(
	[StatisticsCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Analytics_Statistics_StatisticsSiteID] ON [dbo].[Analytics_Statistics]
(
	[StatisticsSiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[Analytics_Statistics] ADD  CONSTRAINT [DEFAULT_Analytics_Statistics_StatisticsCode]  DEFAULT ('') FOR [StatisticsCode]
GO
ALTER TABLE [dbo].[Analytics_Statistics]  WITH CHECK ADD  CONSTRAINT [FK_Analytics_Statistics_StatisticsSiteID_CMS_Site] FOREIGN KEY([StatisticsSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[Analytics_Statistics] CHECK CONSTRAINT [FK_Analytics_Statistics_StatisticsSiteID_CMS_Site]
GO
