SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OM_Score](
	[ScoreID] [int] IDENTITY(1,1) NOT NULL,
	[ScoreName] [nvarchar](200) NOT NULL,
	[ScoreDisplayName] [nvarchar](200) NOT NULL,
	[ScoreDescription] [nvarchar](max) NULL,
	[ScoreEnabled] [bit] NOT NULL,
	[ScoreEmailAtScore] [int] NULL,
	[ScoreNotificationEmail] [nvarchar](998) NULL,
	[ScoreLastModified] [datetime2](7) NOT NULL,
	[ScoreGUID] [uniqueidentifier] NOT NULL,
	[ScoreStatus] [int] NULL,
	[ScoreScheduledTaskID] [int] NULL,
	[ScorePersonaID] [int] NULL,
 CONSTRAINT [PK_OM_Score] PRIMARY KEY CLUSTERED 
(
	[ScoreID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_OM_Score_ScorePersonaID] ON [dbo].[OM_Score]
(
	[ScorePersonaID] ASC
)
WHERE ([ScorePersonaID] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[OM_Score]  WITH CHECK ADD  CONSTRAINT [FK_OM_Score_Personas_Persona] FOREIGN KEY([ScorePersonaID])
REFERENCES [dbo].[Personas_Persona] ([PersonaID])
GO
ALTER TABLE [dbo].[OM_Score] CHECK CONSTRAINT [FK_OM_Score_Personas_Persona]
GO
