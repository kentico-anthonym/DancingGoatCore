SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_PageTemplateConfiguration](
	[PageTemplateConfigurationID] [int] IDENTITY(1,1) NOT NULL,
	[PageTemplateConfigurationGUID] [uniqueidentifier] NOT NULL,
	[PageTemplateConfigurationSiteID] [int] NOT NULL,
	[PageTemplateConfigurationLastModified] [datetime2](7) NOT NULL,
	[PageTemplateConfigurationName] [nvarchar](200) NOT NULL,
	[PageTemplateConfigurationDescription] [nvarchar](max) NULL,
	[PageTemplateConfigurationThumbnailGUID] [uniqueidentifier] NULL,
	[PageTemplateConfigurationTemplate] [nvarchar](max) NOT NULL,
	[PageTemplateConfigurationWidgets] [nvarchar](max) NULL,
 CONSTRAINT [PK_CMS_PageTemplateConfiguration] PRIMARY KEY CLUSTERED 
(
	[PageTemplateConfigurationID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_PageTemplateConfiguration_PageTemplateConfigurationSiteID] ON [dbo].[CMS_PageTemplateConfiguration]
(
	[PageTemplateConfigurationSiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_PageTemplateConfiguration] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplateConfiguration_PageTemplateConfigurationGUID]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [PageTemplateConfigurationGUID]
GO
ALTER TABLE [dbo].[CMS_PageTemplateConfiguration] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplateConfiguration_PageTemplateConfigurationSiteID]  DEFAULT ((0)) FOR [PageTemplateConfigurationSiteID]
GO
ALTER TABLE [dbo].[CMS_PageTemplateConfiguration] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplateConfiguration_PageTemplateConfigurationLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [PageTemplateConfigurationLastModified]
GO
ALTER TABLE [dbo].[CMS_PageTemplateConfiguration] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplateConfiguration_PageTemplateConfigurationName]  DEFAULT (N'') FOR [PageTemplateConfigurationName]
GO
ALTER TABLE [dbo].[CMS_PageTemplateConfiguration] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplateConfiguration_PageTemplateConfigurationTemplate]  DEFAULT (N'') FOR [PageTemplateConfigurationTemplate]
GO
ALTER TABLE [dbo].[CMS_PageTemplateConfiguration]  WITH CHECK ADD  CONSTRAINT [FK_CMS_PageTemplateConfiguration_PageTemplateConfigurationSiteID_CMS_Site] FOREIGN KEY([PageTemplateConfigurationSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[CMS_PageTemplateConfiguration] CHECK CONSTRAINT [FK_CMS_PageTemplateConfiguration_PageTemplateConfigurationSiteID_CMS_Site]
GO
