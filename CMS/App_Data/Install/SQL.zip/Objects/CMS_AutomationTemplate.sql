SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_AutomationTemplate](
	[TemplateID] [int] IDENTITY(1,1) NOT NULL,
	[TemplateDisplayName] [nvarchar](250) NOT NULL,
	[TemplateDescription] [nvarchar](max) NULL,
	[TemplateIconClass] [nvarchar](200) NULL,
	[TemplateConfiguration] [nvarchar](max) NULL,
	[TemplateGuid] [uniqueidentifier] NOT NULL,
	[TemplateLastModified] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_CMS_AutomationTemplate] PRIMARY KEY CLUSTERED 
(
	[TemplateID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_CMS_AutomationTemplate_TemplateDisplayName] ON [dbo].[CMS_AutomationTemplate]
(
	[TemplateDisplayName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_AutomationTemplate] ADD  CONSTRAINT [DEFAULT_CMS_AutomationTemplate_TemplateDisplayName]  DEFAULT (N'') FOR [TemplateDisplayName]
GO
ALTER TABLE [dbo].[CMS_AutomationTemplate] ADD  CONSTRAINT [DEFAULT_CMS_AutomationTemplate_TemplateGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [TemplateGuid]
GO
ALTER TABLE [dbo].[CMS_AutomationTemplate] ADD  CONSTRAINT [DEFAULT_CMS_AutomationTemplate_TemplateLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [TemplateLastModified]
GO
